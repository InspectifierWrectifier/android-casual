echo "remounting system rw...."
mount -o remount,rw /system
echo "moving su into position"
cat /data/local/tmp/su > /system/xbin/su
chown root:shell /system/xbin/su
chmod 6755 /system/xbin/su
echo "moving Superuser.apk into position"
cat /data/local/tmp/Superuser.apk > /system/app/Superuser.apk
chmod 0644 /system/app/Superuser.apk
mount -o remount,ro /system
