mount -o remount,rw /system; 
echo "installing dependencies";
cat /data/local/tmp/viewmem>/system/xbin/viewmem; 
chmod 755 /data/local/viewmem; 
cat /data/local/tmp/busybox>/system/xbin/busybox;
chmod 755 /system/xbin/busybox;
/system/xbin/busybox --install /system/xbin/
mount -o remount,ro /system
echo "done installing dependencies"
