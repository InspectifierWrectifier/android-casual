echo "remounting system rw...."
mount -o remount,rw `mount|/data/local/tmp/busybox grep /system |/data/local/tmp/busybox awk '{print $1}'` /system
echo "moving su into position"
cat /data/local/tmp/su > /system/bin/su
chmod 6755 /system/bin/su
echo "moving Superuser.apk into position"
cat /data/local/tmp/Superuser.apk > /system/app/Superuser.apk
chmod 0644 /system/app/Superuser.apk
su -c "id -u"
