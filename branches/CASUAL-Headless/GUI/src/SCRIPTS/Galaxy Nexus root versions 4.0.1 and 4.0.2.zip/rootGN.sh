echo "remounting system rw...."
mount -o remount,rw -t ext4 /dev/block/mmcblk0p1 /system
echo "moving su into position"
cat /data/local/tmp/su > /system/bin/su
chmod 06755 /system/bin/su
echo "moving Superuser.apk into position"
cat /data/local/tmp/Superuser.apk > /system/app/Superuser.apk
chmod 0644 /system/app/Superuser.apk
mount -o remount,ro -t ext4 /dev/block/mmcblk0p1 /system
