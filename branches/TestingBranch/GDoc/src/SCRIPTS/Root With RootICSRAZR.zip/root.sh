mount -o remount,rw /dev/block/system /system
cat /data/local/su > /system/xbin/su
chown 0.0 /system/xbin/su
chmod 06755 /system/xbin/su
mount -o remount,ro /dev/block/system /system
rm /data/local/mempodroid
rm /data/local/su
rm /data/local/root.sh
